Note from B. Scott Jackson - August 4, 2003

Attached are the two files for the SGfast MEX-function, a replacement for SGmodel. Just mex (compile) the file 'SGfast.c' and put the resultant file and the file 'SGfast.m' in your MATLAB path, and you should be good to go. BTW, 'SGfast.m' is just the MATLAB documentation file (for when you type "help sgfast" at the MATLAB prompt), so it is not actually necessary in order for the MEX-function to work. Enjoy! . . . and let me know if you have any problems or notice anything odd.

BScott


