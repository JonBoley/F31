#ifndef _STIM_H
#define _STIM_H

#include "cmpa.hpp"

/* and some parameter to determin how to test the model */
typedef struct {
  //double tm.wavefile,tm.reptim,tm.banks,tm.delx;an[0].tdres; //should add to parsecommandline()
  char wavefile[100]; //get wave from the file
  int banks; //for filterbank 
  double delx;  //for filter bank

  int stim;
  double tdres; //these two values are very essential, it was alwasy setup at initial 
  int nstim,nrep;
  int runmode;
  double freqt,spl,dur,reptim;    //for tone and other stim
                                  //noise(2),click(3)
  double F1,F2,spl1,spl2;         //for two tone suppression(8)
  double ft;                      //for Huffman sequence(4)
  double z;                       //resonance(5)
  double fm,modind;               //SAM(6),SAM noise(7)
  double splnoi;                  //Tone & Narrowband-noise
  double *buf;
  double rf;                      //rise & fall
  int rfmethod;// rise & fall method
  double cfhi,cflo,cfinc;
  double splhi,spllo,splinc;
  double freqthi,freqtlo,freqtinc;
} T_stim;


//------- These routins are included in fft.sub.c -------
void fftinit(COMPLEX w[],COMPLEX wi[],int n);
void fft(COMPLEX x[],COMPLEX w[],int n);
//---- Following is about the stimulus generate -----

//Get stimulus choice from command line
int GetStimChoise(T_stim *ptm, int idxnow,int argc,char* argv[]);
// Get stimulus choice from interactive way
void stimulus_choice(T_stim *ptm);
void stimulus_generate(T_stim *ptm);

void stimulus_file(T_stim *ptm);
void stimulus_tone(T_stim *ptm);
void stimulus_2tone(T_stim *ptm);
void stimulus_2tone2(T_stim *ptm);
void stimulus_noiseband(T_stim *ptm);
extern T_stim tm;

#endif
