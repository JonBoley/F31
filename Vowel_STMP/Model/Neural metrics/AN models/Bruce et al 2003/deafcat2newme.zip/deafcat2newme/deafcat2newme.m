%deafcat2newme.dll - Bruce et al. (JASA, 2003) Auditory Nerve Model
%
% [timeout,meout,bmout,tausp,vihc,synout,psth] ...
%   = deafcat2newme(pin,bf,nrep,binwidth,stimtime,reptime,cohc,cihc);
%
% timeout is an array of times in milliseconds
% meout is the output of the middle-ear filter
% bmout is the output of the basilar-membrane (narrowband, signal-path) filter
% tausp is the BM filter time-constant
% vihc is the inner hair cell potential
% synout is the synapse output in spikes/s
% psth is the peri-stimulus time histogram
%
% pin is the input sound wave in Pa sampled at 500 kHz
% bf is the best frequency of the fiber in Hz
% nrep is the number of repetitions for the psth
% binwidth is the binsize in milliseconds - NOTE should be set to 0.002
% stimtime is the duration of the stimulus in milliseconds - NOTE should be longer than the duration of pin
% reptime is the time between stimulus repetitions in milliseconds - NOTE must be longer than stimtime
% cohc is the ohc scaling factor: 1 is normal OHC function; 0 is complete OHC dysfunction
% cihc is the ihc scaling factor: 1 is normal IHC function; 0 is complete IHC dysfunction
%
% Fore example,
%
%   [timeout,meout,bmout,tausp,vihc,sout,psth] ...
%    = deafcat2newme(pin,1e3,100,0.002,150,200,1,1);
%
% models a normal fiber (normal OHC & IHC function) with a BF of 1 kHz, for 100 repititions and
% a sampling frequency of 500kHz, for 200 ms (with a stimulus duration of 150 ms)
