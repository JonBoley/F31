#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> /* Added for MS Visual C++ compatability, by Ian Bruce, 1999 */
#include <mex.h>
#include <time.h>

#include "cmpa.hpp"
#include "complex.hpp"
#include "stim.hpp"

#define MAXSPIKES 100000
//#define MAXSPIKES 2000000
#define Prms_eh30 6.32455528e-4 /* New scaling for Elizabeth Allegretto's vowels */

#ifndef __max
#define __max(a,b) (((a) > (b))? (a): (b))
#endif

double sptime[MAXSPIKES]; //spike time storage

/*
typedef struct {
	char wavefile[100]; //filename for stimulus waveform
	int banks; //number of filters in filterbank
	double delx;  //"delta x", or spacing of "IHC"s along BM (linearly spaced IHCs in terms of location along BM
				//  results in approximately logarithmic spacing in terms of frequency.
	int stim;
	double tdres; //time step (time domain resolution)
	int nstim,nrep; // nstim=number of pts in stimulus; nrep is number of reps of stimulus
	int runmode;
	double freqt,spl,dur,reptim;    //for tone and other stim
	//noise(2),click(3)
	double F1,F2,spl1,spl2;         //for two tone suppression(8)
	double *buf;
	double rf;                      //rise & fall
	int rfmethod;// rise & fall method
	double cfhi,cflo,cfinc;
	double splhi,spllo,splinc;
	double freqthi,freqtlo,freqtinc;
} T_stim;
*/

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	
	double *px, cf, binwidth, stimtime, reptime, spont, cohc, cihc;
	int nrep, stimtype, middleear, species, pxbins, lp;
	double *pxtmp, *cftmp, *binwidthtmp, *stimtimetmp, *reptimetmp;
	double *nreptmp, *cohctmp, *cihctmp;
	
    double *timeout, *py, *pfarray, *farray, *vihct, *soutarray, *psth;
	
	void SingleAN(double *, int, double, int, double, double, double, int, int, double, double, double,
			  double *, double *, double *, double *, double *, double *, double *);
	
	int outsize[2];
	
	/* Check for proper number of arguments */
	
	if (nrhs != 8) {
		mexErrMsgTxt("deafcat2newme requires 8 input arguments.");
	} else if (nlhs != 7) {
		mexErrMsgTxt("deafcat2newme requires 7 output arguments.");
	}
	
	/* Assign pointers to the inputs */

	pxtmp		= mxGetPr(prhs[0]);
	cftmp		= mxGetPr(prhs[1]);
	nreptmp		= mxGetPr(prhs[2]);
	binwidthtmp	= mxGetPr(prhs[3]);
	stimtimetmp	= mxGetPr(prhs[4]);
	reptimetmp	= mxGetPr(prhs[5]);
    cohctmp		= mxGetPr(prhs[6]);
    cihctmp		= mxGetPr(prhs[7]);
	
	binwidth	 = binwidthtmp[0];
	if (binwidth!=0.002)
	{
		mexErrMsgTxt("binwidth should be 0.002ms (Fs = 500kHz) for normal usage.\n");
	}
	
	cf			 = cftmp[0];
	if ((cf<80)|(cf>15e3))
	{
		mexPrintf("cf (= %1.1f Hz) must be between 80 Hz and 15 kHz\n",cf);
		mexErrMsgTxt("\n");
	}
	
	nrep = (int)nreptmp[0];
	if (nreptmp[0]!=nrep)
		mexErrMsgTxt("nrep must an integer.\n");
	if (nrep<1)
		mexErrMsgTxt("nrep must be greater that 0.\n");

	stimtime = stimtimetmp[0];
	if (stimtime<0)
		mexErrMsgTxt("stimtime must be positive.\n");

	reptime = reptimetmp[0];
	if (reptime<stimtime)
		mexErrMsgTxt("reptime should be equal to or longer than stimtime.\n");

    middleear    = 1;
    species		 = 1;
    spont		 = 50;

    cohc = cohctmp[0];
	if ((cohc<0)|(cohc>1))
	{
		mexPrintf("cohc (= %1.1f) must be between 0 and 1\n",cohc);
		mexErrMsgTxt("\n");
	}

	cihc = cihctmp[0];
	if ((cihc<0)|(cihc>1))
	{
		mexPrintf("cihc (= %1.1f) must be between 0 and 1\n",cihc);
		mexErrMsgTxt("\n");
	}

	outsize[0] = 1;
	outsize[1] = (int)ceil(reptime/binwidth);

    px = (double*)mxCalloc(outsize[1],sizeof(double)); 

	pxbins	= mxGetN(prhs[0]);
	if (pxbins==1)
		mexErrMsgTxt("px must be a row vector\n");

	for (lp=0; lp<outsize[1]; lp++)
	{
		if (lp<pxbins)
			px[lp] = pxtmp[lp];
		else
			px[lp] = 0.0;
	}
	
	/* Create an array for the return argument */
	
	plhs[0] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	plhs[1] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	plhs[2] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	plhs[3] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	plhs[4] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	plhs[5] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	plhs[6] = mxCreateNumericArray(2, outsize, mxDOUBLE_CLASS, mxREAL);
	
	/* Assign pointers to the outputs */
	
	timeout		= mxGetPr(plhs[0]);
	py			= mxGetPr(plhs[1]);
	pfarray		= mxGetPr(plhs[2]);
	farray		= mxGetPr(plhs[3]);
	vihct		= mxGetPr(plhs[4]);
	soutarray	= mxGetPr(plhs[5]);
	psth		= mxGetPr(plhs[6]);
		
	/* run anmodel */
	mexPrintf("Bruce et al. (JASA, 2003) Auditory Nerve Model\n");

	SingleAN(px, pxbins, cf, nrep, binwidth, stimtime, reptime, middleear, species, spont, cohc, cihc,
		timeout, py, pfarray, farray, vihct, soutarray, psth);
	
	
}

void SingleAN(double *px, int pxbins, double cf, int nrep, double binwidth, double stimtime, double reptime, int middleear, int species, double spont, double cohc, double cihc,
			  double *timeout, double *py, double *pfarray, double *farray, double *vihct, double *soutarray, double *psth)
{
	static T_stim tm;                    // structure to store the input parameters
	static TAuditoryNerve an[1];              // 1 filter bank
	
	int nspikes;
	FILE *fpstim;          //open these file when run
	double buf; //tempory value to store the stimulus
	double delay;
	int delaypoint;
	long flag,nowstim,totalstim;
	double *pfarraytmp, *vihcttmp, *soutarraytmp;

  //variables for MEX interface to MATLAB
  double num,scalefac,t;
  int mxpts,irpts,lp;

  //variables for middle-ear model
  int n;
    double *mey1, *mey2, *mey3;
    //double megainmax=38.9856;
    double megainmax=43;

	int synapse(TAuditoryNerve *, int, int, double *, double *);
	
	an[0].tdres = tm.tdres = binwidth*1e-3; // sample rate
	an[0].cf = cf;                     // CF
	an[0].spont = spont;                    // spont rate
	an[0].cohc = cohc;                    // OHC condition
	an[0].cihc = cihc;                    // OHC condition
	
	//strcpy(tm.wavefile,"click");         //input file
	
	tm.reptim = reptime*1e-3;                   //time
	tm.dur = stimtime*1e-3;
	tm.nrep = nrep;
	tm.spl = 0;

	nowstim = 0;
	totalstim = (long)(tm.reptim/an[0].tdres);
    an[0].nstim = tm.nstim = (int) totalstim;
	tm.buf = (double*)mxCalloc(totalstim,sizeof(double)); 

	pfarraytmp = (double*)mxCalloc(totalstim,sizeof(double));
	vihcttmp = (double*)mxCalloc(totalstim,sizeof(double));
	soutarraytmp = (double*)mxCalloc(totalstim,sizeof(double));

	buf = 0.0;
	
/*	// ******************now begin to pass the stimulus to the model************************
	// Read in the stimulus
	if ((fpstim = fopen(tm.wavefile,"r"))==NULL)
		mexErrMsgTxt("Couldn't open file\n");
	nowstim=0;
	while((fscanf(fpstim,"%le",&px[nowstim]) != EOF))
		nowstim++;
	fclose(fpstim);
*/

  for (lp = 0; lp < tm.nstim; lp++)
	  tm.buf[lp] = px[lp];

/* Do ramping of stimulus internally */
/*	  mxpts = pxbins;
	  irpts = (int)(tm.rf / tm.tdres);
	  t = 0.0;
	  for(lp = 0; lp < irpts; lp++)
	  {
		  t = t + 1.0;
		  tm.buf[lp] *= (t / irpts);
	  }
	  t = t + (double)(mxpts-2*irpts);
	  for(lp = (mxpts-irpts); lp < mxpts; lp++)
	  {
		  t = t + 1.0;
		  tm.buf[lp] *= ((mxpts-t) / irpts);
	  } */

if (middleear==1)
{

  mexPrintf("- Using new middle ear model\n");

	mey1 = (double*)mxCalloc(totalstim,sizeof(double));
	mey2 = (double*)mxCalloc(totalstim,sizeof(double));
	mey3 = (double*)mxCalloc(totalstim,sizeof(double));

  mey1[0] = px[0];
  mey2[0] = mey1[0];
  mey3[0] = mey2[0];
  py[0] = 0.5472*mey3[0]/megainmax;
	
  mey1[1] = 0.9986*mey1[0]+px[1]+px[0];
  mey2[1] = 1.9777*mey2[0]+mey1[1]-1.9998*mey1[0];
  mey3[1] = 1.9856*mey3[0]+mey2[1]-1.9943*mey2[0];
  py[1] = 0.5472*mey3[1]/megainmax;

for (n=2;n<totalstim;n++)
{    
  mey1[n] = 0.9986*mey1[n-1]+px[n]+px[n-1];
  mey2[n] = 1.9777*mey2[n-1]-0.9781*mey2[n-2]+mey1[n]-1.9998*mey1[n-1]+0.9998*mey1[n-2];
  mey3[n] = 1.9856*mey3[n-1]-0.9892*mey3[n-2]+mey2[n]-1.9943*mey2[n-1]+0.9973*mey2[n-2];
  py[n] = 0.5472*mey3[n]/megainmax;
}

}
else
{

//  mexPrintf("; Middle ear omitted");
	
//  memcpy((char *) px, (char *) tm.buf, tm.nstim*sizeof(double)); 
  memcpy((char *) py, (char *) tm.buf, tm.nstim*sizeof(double));
}

/* End middle-ear filtering section - Added by Ian Bruce */

	// construct the model
	an[0].construct();
	an[0].init(cf,an[0].spont);

	double sthr = 0;
//	mexPrintf("\n  Spont = %4.2f spikes/s",spont);
//	mexPrintf("; Threshold for Sout is %4.2f spikes/s",sthr);

	flag = 0; //if = 1,don't read from stimulus file but set zero as input
	nowstim = 0;
	while(nowstim<totalstim)
    {
		buf = py[nowstim];
		timeout[nowstim]=(double)nowstim*an[0].tdres*1e3;
		an[0].run(buf);
		pfarraytmp[nowstim]=an[0].bmbuf;
		//farray[nowstim]=an[0].tau;
		farray[nowstim]=an[0].taunow;
		//farray[nowstim]=an[0].ohcout;
		//farray[nowstim]=an[0].wbout;
		//farray[nowstim]=an[0].ihcbeforelp;
		//farray[nowstim]=an[0].grd;
		vihcttmp[nowstim]=an[0].ihcbuf;
		soutarraytmp[nowstim]=an[0].sbuf;
        if (sthr>0)
		{
            if (soutarraytmp[nowstim]>sthr)
				//soutarraytmp[nowstim] = soutarraytmp[nowstim];
				//soutarraytmp[nowstim] = soutarraytmp[nowstim]-sthr;
				soutarraytmp[nowstim] = sthr/(0.0-1*log(1-sthr/soutarraytmp[nowstim]));
			else
				soutarraytmp[nowstim] = 0;
        }

		nowstim++;
	}; //end of while

	/* Add BM traveling-wave delay to all signals after BM */


	delay = delay_cat(cf);
    delaypoint=__max(0,(int)ceil(delay/tm.tdres));

	int i;

    for(i=0;i<delaypoint;i++)
	{
		pfarray[i]=0.0;
		vihct[i]=0.0;
		soutarray[i]=spont;
	}
    for(i=delaypoint;i<totalstim;i++)
	{
		pfarray[i]=pfarraytmp[i-delaypoint];
		vihct[i]=vihcttmp[i-delaypoint];
		soutarray[i]=soutarraytmp[i-delaypoint];
	}

	nspikes = synapse(&an[0],totalstim,tm.nrep,soutarray,sptime);
	double bin = tm.tdres;
	//int nbins = (int)(tm.reptim / bin + 1);
	int nbins = (int)floor(tm.reptim / bin);
	/* Construct PST HISTOGRAM, Interval hist, Period hist.  */
	for(i = 0; i < nbins; i++)
		psth[i] = 0.0;
	for(i = 0; i < nspikes; i++)
	{
		/* both sptime and bin are in secs */
		int ipst = (int)(fmod(sptime[i],tm.tdres*totalstim) / bin);
        psth[ipst] = psth[ipst] + 1;
	}
	
mxFree(tm.buf); 
mxFree(pfarraytmp);
mxFree(vihcttmp);
mxFree(soutarraytmp);
mxFree(mey1);
mxFree(mey2);
mxFree(mey3);


};

// --------------------------------------------------------------------------------
/** this routine generates spike times according to *sout with nrep representation
put the spikes time into buffer *spikes, nspikes
*/
int synapse(TAuditoryNerve *pan,int nstim,int nrep,double *sout,double *sptime)
{
	int i,j,isp;
	int nspikes = 0;
	/* sout[] contains prob of spike vs. time - run through it nrep times to look for spikes */
	isp = 0;
	sptime[0] = 0.; /* start out with a spike at t=0 on 1st rep */
	pan->sg->init(sout[0]); //initialize the spike generator
	for(i = 0; i < nrep; i++)
    {
		pan->sg->init(sout[0]);
		for( j = 0; j < nstim; j++)
		{
			if(pan->sg->run(sout[j])==1)
			{
				sptime[isp] = pan->sg->Get_rtime();  /* leave sptime in sec */
				isp++;
				if(isp>MAXSPIKES) mexErrMsgTxt("\nToo many spikes generated: increase MAXSPIKES\n");
			}
		}
		nspikes = isp;
    };
	return nspikes;
};
