/** \file cmpa.cpp
 * \brief This file contains several useful routines 
 * TAuditoryNerve::construct : construct the fiber model
 * TAuditoryNerve::init      : initialize the parameters of the model (These two must be called)
 * TAuditoryNerve::run       : pass the signal through the Model (not the spikes)

 * synapse() synapse2()      : generate spikes using output of the model
 * Get_tau()                 : How the tau of the time-varing tuning filter is determined
 * TBasilarMembrane::run()   : pass the signal through the tuning filter
*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>
#include <time.h>
#include <mex.h>

#include "cmpa.hpp"
#include "complex.hpp"
#include "filters.hpp"
#include "hc.hpp"
#include "synapse.hpp"


// -------------------------------------------------------------------------
/**
 * run the model\n
 * Input signal->(time-varying filter+1st-order gamma-tone filter)
 * ->inner hair cell->synapse model
 */
double TAuditoryNerve::run(double in)
{ //inbuf,tau,bmbuf,ihcbuf,sbuf are variables in the CLASS
  //bm,gfagain,ihc,syn are variables(CLASS pointer) in the CLASS
  inbuf		= in;
  double bmbuf1	= bm->run(in);
  wbout		= bm->GetWBOUT();
  //wbout		= bmbuf1;
  ohcout    = bm->GetOHCOUT();
  tau    	= bm->GetTau();
  taunow    = bm->GetTaunow();
  grd		= bm->GetGRD(bm->nowstim - 1);
  bmbuf 	= gfagain->run(bmbuf1);
  //ihcbuf 	= ihc->run(bmbuf);
  ihcbuf 	= ihc->run(cihc*bmbuf);
  ihcbeforelp = ihc->GetIHCBEFORELP();
  //ihcbuf 	= ihc->run(0.004*bmbuf);
  //ihcbuf 	= ihc->run(0.006*bmbuf);
  //ihcbuf 	= ihc->run(0.003*bmbuf);
  //ihcbuf 	= ihc->run(0.02*bmbuf);
  sbuf   	= syn->run(ihcbuf);
  return(sbuf);
};

// --------------------------------------------------------------------------
/** construct the default nerve, alloc all the memory and so on,
   the tdres,mode should be specified, the cf independent parameters should be determined
   in this function, others are specified in init(...) function
*/
void TAuditoryNerve::construct(void)
{ //default
  bm = new TBasilarMembrane(tdres);
  bm->wbfilter = new TGammaTone;
  bm->wbgfagain = new TGammaTone;
  bm->afterohc = new TNL_AfterOHC;

  bm->grd = (int*)mxCalloc(nstim,sizeof(int)); 
  bm->tmpgain = (double*)mxCalloc(nstim,sizeof(double));

  /* *** FOLLOWING PARAMETERS ARE NOT CF,SPONT,or SPECIES DEPENDENT *** */
  double absdb = 20; /* The value that the BM starts compression */
  /* ********************* Init OHC model *******************************/
  //bm->ohc = new THairCell(tdres,800.0,5);
  //bm->ohc = new THairCell(tdres,800.0,3);
  bm->ohc = new THairCell(tdres,600.0,3);
//  mexPrintf("\n  OHC LPF cutoff of 600 Hz");
  //mexPrintf("; Using 4th-order OHC LPF");
  /* parameter into boltzman is corner,slope,strength,x0,s0,x1,s1,asym */
  /* The corner determines the level that BM have compressive nonlinearity*/
  //ohcasym = 7.0; //CLASS variable
  ohcasym = 7.0; //CLASS variable
  bm->ohc->init_boltzman(absdb-12,0.22,0.08,5,12,5,5,ohcasym);
  //mexPrintf("\n  Using OHC asymetry of %i",(int)ohcasym);
  //bm->ohc->init_boltzman(absdb-12,0.19,0.08,5,12,5,5,ohcasym);
  //mexPrintf("\n Using modified slope for OHC log NL");

  /* ******** Init the gammatone filter after the bm tuning filter *******/
  gfagain = new TGammaTone;
  /* ********************* Init Inner Hair Cell *************************/
  ihc = new THairCell(tdres,3800.0,7);
  //ihc = new THairCell(tdres,3800.0,6);
  //mexPrintf("; Using 6th-order IHC LPF");
  //Using new nonlinear function p_corner,p_slope, p_str, asym
  ihc->init_logrithm(80,0.1,0.12,3);
  //ihc->init_logrithm(100,0.1,0.12,3);
  //mexPrintf(";\n  Using IHC NL corner of 100 dB SPL");
  /* ihc->init_logrithm(80,0.05,0.12,3);
  mexPrintf(";\n  Using IHC NL slope of 0.05"); */
  /* ihc->init_logrithm(80,0.1,0.12,8);
  mexPrintf(";\n  Using IHC NL asymmetry of 8"); */
  /********************** Init Synapse *********************************/
  syn = new TSynapse_WS(tdres);
  /********************** Init Spike Generator *************************/
  /* Spike history parameters- for two exponents ala Westerman and Smith '89
     these values fit Gaumond & Kim's spontaneous, and also fit noise responses. */
  /* parameter into SG is dead,c0,s0,c1,s1 in units of sec */
  sg = new TSpikeGenerator(tdres,0.00075,0.5,0.001,0.5,0.0125);
};

// --------------------------------------------------------------------------------
void TAuditoryNerve::init(double _cf,double _spont)
{
  int i;
  cf = _cf;
  if(_spont<0) spont = 50;
  else spont = _spont;

  int bmorder = 3;
  /* set up the tau0 and taurange of time-varing gammatone filter */
  Get_tau(cf,bmorder,taumax,tau0,taurange);
//  mexPrintf("\n  TauMax = %4.3e; TauMin = %4.3e",taumax,tau0);  
  //bm->tau = taumax;
  bm->cohc = cohc;
  bm->tau = bm->cohc*taurange+tau0;
  /* *** FOLLOWING PARAMETERS ARE CF,SPONT,or SPECIES DEPENDENT *** */
  //bm->init(cf,taumax,tau0,bmorder);
  bm->init(cf,taumax,tau0,bmorder,bm->cohc);
  gfagain->init(tdres,cf,tau0,  1.0,1); //non-time-varying gammatone filter that follows time-varying filter
  /* ******************** Init WideBand Filter ****************************/
  int species = 1; //for CAT
  double x = cochlea_f2x(species,cf);
  double centerfreq = cochlea_x2f(species,x+1.2); //shift the center freq
  //double centerfreq = cf;
//  mexPrintf("\n  Fcp = %4.3e",centerfreq);
  int wb_order = 3;
  double tauwb = tau0+0.2*(taumax-tau0);
  //double tauwb = tau0+0.3*(taumax-tau0);
  bm->TauWB = tauwb;
  bm->TauWBMin = tauwb/taumax*tau0;
  bm->taunow = tauwb/taumax*bm->tau;
  //bm->TauWBMin = tau0;
  //mexPrintf("\n  TauWBMin = TauMin"); 
  double dtmp = tauwb*TWOPI*(centerfreq-cf);
  //double wb_gain = pow((1+dtmp*dtmp), (double) wb_order/2.0);
  double tmpcos = cos(TWOPI*(centerfreq-cf)*tdres);
  double dtmp2 = bm->taunow*2.0/tdres;
  double c1LP = (dtmp2-1)/(dtmp2+1);
  double c2LP = 1.0/(dtmp2+1);
  double tmp1 = 1+c1LP*c1LP-2*c1LP*tmpcos;
  double tmp2 = 2*c2LP*c2LP*(1+tmpcos);
  //double wb_gain = pow(tmp1/tmp2, (double) wb_order/2.0);
  double wb_gain = pow(tmp1/tmp2, 1.0/2.0);
  //double wb_gain = 1.0;
  bm->wbfilter->init(tdres,centerfreq,bm->taunow,wb_gain,wb_order);
  bm->nowstim = 0;
  bm->nstim = nstim;
  for (i = 0; i < nstim; i++)
  {
	bm->tmpgain[i] = 0;
	bm->grd[i] = 0;
  }
  bm->tmpgain[0] = wb_gain;
  //double dtmp2 = bm->TauWBMin*TWOPI*(centerfreq-cf);
  //double wbgfagain_gain = pow((1+dtmp2*dtmp2), 0.5);
  //bm->wbgfagain->init(tdres,centerfreq,bm->TauWBMin,wbgfagain_gain,1);
  /* ********************* Init Nonlinear After OHC *********************/
  /* parameter into nonlinear function is Taumin,taumax,dc,minR        */
  double dc = (ohcasym-1)/(ohcasym+1.0)/2.0;
  bm->afterohc->init(tau0,taumax,dc-0.05,0.05);
  /* ********************* Init Synapse ********************************/
  double PImax = 0.6;
  //double cf_factor = 2+3*log10(cf/1000);
  //if (cf_factor<1.5) cf_factor = 1.5;
  //double cf_factor = 0.0016*cf + 0.46;
  //double cf_factor = 0.0032*cf;
  //double cf_factor = 0.12; // 200 Hz
  //double cf_factor = 0.5; // 400 Hz
  //double cf_factor = 2.7; // 800 Hz
  //double cf_factor = 3.5; // 1 kHz
  //double cf_factor = 3.5; // 1.5 kHz
  //double cf_factor = 4.7; // 2.0 kHz
  //double cf_factor = 5.5; // 3.0 kHz
  //double cf_factor = 10.0; // 4.0 kHz
  //double cf_factor = 11.6; // 5.0 kHz
  //double cf_factor = 20.0; // 6.0 kHz
  //double cf_factor = 38.0; // 7.0 kHz
  //double cf_factor = pow(10,0.24*cf/1e3 + 0.5)/10;
  //double cf_factor = pow(10,0.1*cf/1e3 + 0.5 - 1.24);
  /* Use the following with the Bruce et al. (JASA 2003) middle ear model */
  //double cf_factor = pow(10,0.24*cf/1e3 + 0.5);
  //  mexPrintf(";\n  Using exponential synapse-gain vs cf function");
  /* Use the following with the new middle ear model */
 double cf_factor;
 cf_factor = pow(10,0.29*cf/1e3 + 0.4);
 if (cf_factor > 1e3)
	 cf_factor = 1e3;
  mexPrintf("- Using new saturated exponential synapse-gain vs BF function\n");
  double kppi = (1+spont)/(5+spont)*cf_factor*20*PImax;
  double vsat = kppi;                           //in fact vsat = kppi+PI1
  syn->setppi_mgheinz(kppi);   // set the IHC-PPI nonlinearity as soft-rectifier
  //syn->setppi_linear(kppi);   // set the IHC-PPI nonlinearity as hard-rectifier
  //mexPrintf(";\n  Using linear (hard-rectified) IHC-PPI function");
  //mexPrintf(";\n  Using quadratic (and hard-rectified) IHC-PPI function");
  /* parameter into synapse is Ass,Asp,TauR,TauST,Ar_Ast,PI2,vsat */
  syn->init_WS(350.0,spont,2e-3,60e-3,6,0.6,vsat); //vsat is not used now until kppi is set to negtive
  /* syn->init_WS(350.0,spont,0.1e-3,60e-3,6,0.6,vsat); //vsat is not used now until kppi is set to negtive
  mexPrintf(";\n  Using TauR of 0.1 ms"); */
};

// --------------------------------------------------------------------------------
/** Get TauMax, TauMin for the tuning filter. The TauMax is determined by the bandwidth/Q10
    of the tuning filter at low level. The TauMin is determined by the gain change between high
    and low level
    Also the calculation is diffrent for different species
 */
double Get_tau(double cf,int order, double &taumax,double &taumin,double &taurange)
{
  double Q10,bw,gain,ratio;
  double xcf, x1000;
  //gain = 20+42*log10(cf/1e3);                // estimate compression gain of the filter
  //gain = 30+51*log10(cf/1e3);                // estimate compression gain of the filter
  //gain = 56/2*(tanh(2.2*log10(cf/1e3)+0.15)+1);
  gain = 52/2*(tanh(2.2*log10(cf/1e3)+0.15)+1);
  if(gain>70) gain = 70;
  //gain = 6.4+154.5*log10(cf/1e3);                // estimate compression gain of the filter
  //if(gain>42) gain = 42;
  if(gain<15) gain = 15;
  //gain = 36;
  //gain = 15; // 0.2 kHz
  //gain = 15; // 0.5 kHz
  //gain = 42; // 1.0 kHz
  //gain = 24; // 1.3 kHz
  //gain = 44; // 1.3 kHz
  //gain = 42; // 1.7 kHz
  //gain = 44; // 1.7 kHz
  //gain = 42; // 2.2 kHz
  //gain = 48; // 2.2 kHz
  //gain = 42; // 2.7 kHz
  //gain = 60; // 2.7 kHz
//  mexPrintf("\n  Cochlear amplifier gain = %4.2f",gain);
  ratio = pow(10,(-gain/(20.0*order))); // ratio of TauMin/TauMax according to the gain, order

  // Calculate the TauMax according to different species
  /* Universal species from data fitting : From Xuedong Zhang & Ian Bruce */
  /* the value of Q10 determines the taumax(bandwidths at low level) Based on Cat*/
  //Q10 = pow(10,0.4708*log10(cf/1e3)+0.4664-0.0730);  // 25th percentile
  Q10 = pow(10,0.4708*log10(cf/1e3)+0.4664);  // 50th percentile
  //Q10 = pow(10,0.4708*log10(cf/1e3)+0.4664+0.0805);  // 75th percentile
  //Q10 = 4.7; // produces ~ 4.3 at CF = 2.5 kHz
  //Q10 = 2.0; // produces ~ ? at CF = 1.5 kHz
  bw = cf/Q10;
  taumax = 2.0/(TWOPI*bw);
  taumin =  taumax*ratio;
  taurange = taumax-taumin;
  return 0;
};

// --------------------------------------------------------------------------------
/** Calculate the location on Basilar Membrane from best frequency
*/
double cochlea_f2x(int species,double f)
{
  double x;
  switch(species)
    {
    default:
    case 1: //cat
      x = 11.9 * log10(0.80 + f / 456.0);
      break;
    };
  return(x);
};
// --------------------------------------------------------------------------------
/** Calculate the best frequency from the location on basilar membrane
 */
double cochlea_x2f(int species,double x)
{
  double f;
  switch(species)
    {
     default:
    case 1: //cat
      f = 456.0*(pow(10,x/11.9)-0.80);
      break;
    };
  return(f);
};
// --------------------------------------------------------------------------------
/** error: print an error message and die gracefully
    Takes arguments like printf
    Copied from Kernighan and Ritchie, p 174
*/
void error(char *fmt)
{
  fprintf(stderr, "error: ");
  fprintf(stderr, fmt);
  fprintf(stderr, "\n");
  exit(1);  /* closes all open files */
}
// ---------------------------------------------------------------------------
/** Calculate the delay(basilar membrane, synapse for cat*/
double delay_cat(double cf)
{
  /* DELAY THE WAVEFORM (delay buf1, tauf, ihc for display purposes)  */
  /* Note: Latency vs. CF for click responses is available for Cat only (not human) */
  /* Use original fit for Tl (latency vs. CF in msec) from Carney & Yin '88
     and then correct by .75 cycles to go from PEAK delay to ONSET delay */
  double A0 = 8.13; /* from Carney and Yin '88 */
  double A1 = 6.49;
  double x = cochlea_f2x(1,cf); //cat mapping
  double delay = A0 * exp( -x/A1 ) * 1e-3 - 1.0/cf;
  //mexPrintf("; Delay = %5.4f",delay);
return(delay);
};
// ----------------------------------------------------------------------------------------------
/** pass the signal through the tuning filter.
    using different model
    Sharp_Linear | Broad_Linear | Broad_Linear_High | FeedBack_NL | FeedForward_NL
*/
double TBasilarMembrane::run(double x)
{

  double out;
  int i;
  double x1 = bmfilter->run(x); // pass the signal through the tuning filter
  out = pow((tau/TauMax),bmfilter->GetOrder())*x1;  // Gain Control of the tuning filter
  wbout = wbfilter->run(x);    //get the output of the wide-band pass as the control signal
  //double x2 = wbfilter->run(x);    //get the output of the wide-band pass as the control signal
  //wbout = wbgfagain->run(x2);
  wbout *= pow((taunow/TauWB),wbfilter->GetOrder());

  ohcout = ohc->run(wbout); // pass the control signal through OHC model
  //tau = afterohc->run(ohcout);     // pass the control signal through nonliearity after OHC
  double tmptau = afterohc->run(ohcout);     // pass the control signal through nonliearity after OHC
  tau = cohc*(tmptau-TauMin)+TauMin;  // To make Q10 change linearly with COHC
  //tau = pow(TauMin/tmptau,(1-cohc))*tmptau; // To make gain_dB change linearly with COHC
  //tau = TauMax;
  bmfilter->settau(tau);           // set the tau of the tuning filter

  static double A=(TauWB/TauMax-TauWBMin/TauMin)/(TauMax-TauMin);
  static double B=(TauMin*TauMin*TauWB-TauMax*TauMax*TauWBMin)/(TauMax*TauMin*(TauMax-TauMin));
  //double taunow = A*tau*tau-B*tau;
  taunow = A*tau*tau-B*tau;
  //double taunow = TauWB;
  wbfilter->settau(taunow);        //set the tau of the wide-band filter
  // normalize the gain of the wideband pass filter as 0dB at CF
  double dtmp = taunow*TWOPI*(wbfilter->getF()-bmfilter->getF());
  double cntrfrq = wbfilter->getF();
  double cftmp = bmfilter->getF();
  double wb_gain_alt = pow((1+dtmp*dtmp), wbfilter->GetOrder()/2.0);
  double tmpcos = cos(TWOPI*(wbfilter->getF()-bmfilter->getF())*tdres);
  double dtmp2 = taunow*2.0/tdres;
  double c1LP = (dtmp2-1)/(dtmp2+1);
  double c2LP = 1.0/(dtmp2+1);
  double tmp1 = 1+c1LP*c1LP-2*c1LP*tmpcos;
  double tmp2 = 2*c2LP*c2LP*(1+tmpcos);
  //double wb_gain = pow(tmp1/tmp2, wbfilter->GetOrder()/2.0);
  double wb_gain = pow(tmp1/tmp2, 1.0/2.0);
  //grd[nowstim] = (int)floor(wbfilter->GetOrder()*(0.5-(c1LP*c1LP-c1LP*tmpcos)/(1+c1LP*c1LP-2*c1LP*tmpcos)));
  grd[nowstim] = (int)floor((0.5-(c1LP*c1LP-c1LP*tmpcos)/(1+c1LP*c1LP-2*c1LP*tmpcos)));
  if ((grd[nowstim]+nowstim)<nstim)
	  tmpgain[grd[nowstim]+nowstim] = wb_gain;

  if (tmpgain[nowstim] == 0)
  {
	  for (i = nowstim-1; i >= 0; i--)
	  {
		  if (tmpgain[i]>0)
		  {
			  tmpgain[nowstim] = tmpgain[i];
			  break;
		  }
	  }
  }
  //wbfilter->setgain(wb_gain);
  //wbfilter->setgain(1.0);
  wbfilter->setgain(tmpgain[nowstim]);

  nowstim += 1;

  return(out);
};
