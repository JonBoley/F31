%%% readme.txt for deafcat2newme %%%

This is a public distribution of the code for the auditory periphery model of:

    Bruce, I. C., Sachs, M. B., and Young, E. D. (2003). "An auditory-periphery
    model of the effects of acoustic trauma on auditory nerve responses,"
    Journal of the Acoustical Society of America 113(1):369�388.

with a modified version of the middle-ear section of the model.  The middle-ear
filter has been simplified to:

a) avoid stability problems encountered with the discrete-time implementation
of the filter, and

b) decrease the computational complexity and increase the computational speed
of this section of the model.

The synapse gain given by Eqn. (1) of Bruce et al. (2003) has consequently been
modified slightly to:

a) compensate for the changed middle-ear frequency response, and

b) give more accurate thresholds for model AN fibers with best frequencies
(BFs) between 10 and 40 kHz, when compared with the best threshold curve (BTC)
of Liberman, M. C. (1978). "Auditory nerve response from cats raised in a low
noise chamber," J. Acoust. Soc. Am. 63, 442�455. In Bruce et al. (2003), I did
not consider fibers with BFs above 10 kHz.  Note that thus far I've only tested
out the threshold vs BF predictions with this new middle-ear model, so I can't
ensure that the suprathreshold behavior of model fibers with BFs between 10 and
40 kHz bears any resemblance to that of real cat AN fibers!

Please cite the Bruce et al. (2003) paper if you publish any research results
obtained with this code or any modified versions of this code.  Please let me
know if you need details of the modifications to the middle-ear filter and
synapse gain function.  I will include the details in the first publication
that makes use of the new model, but I cannot promise how soon any such
publication will appear.

The Matlab and C++ code included with this distribution is designed to be
compiled as a Matlab MEX file, i.e., the compiled model MEX function will run
as if it were a Matlab function.  The code can be compiled within Matlab using
the function:

    mexdeafcat2newme_msc.m      if you are using a Microsoft C compiler, or

    mexdeafcat2newme_unix.m     if you are using a compiler such as gcc on a Unix
                                system.

The reason for the difference is that Unix compilers typically include the
drand48() random number generator, which has the precision required for spike
generation in this model.  Microsoft C compilers do not include drand48(), so I
have made use of the Gnu Scientific Library (GSL;
http://www.gnu.org/software/gsl/) equivalent.  The required files from the GSL
are included with this distribution, as is a copy of the GNU General Public
License (gpl.txt), under which the GSL is released. I have not tested the code
with any C compilers other than MS Visual C++ 6.0 on MS Windows 2000 and gcc on
Redhat Linux.

Once you have compiled the MEX file in Matlab, type:

    help deafcat2newme

for instructions on how to call the MEX function.

I have also include a sample Matlab script for setting up an acoustic stimulus
and the model parameters and running the model:

    test_deafcat2newme.m


ACKNOWLEDGMENTS

A large amount of the code was written by Xuedong (Frank) Zhang, Michael Heinz
and Laurel Carney for the model of:

    Zhang, X., Heinz, M. G., Bruce, I. C., and Carney, L. H. (2001). "A
    phenomenological model for the responses of auditory-nerve fibers: I.
    Nonlinear tuning with compression and suppression," J. Acoust. Soc. Am. 109,
    648�670,

on which the Bruce et al. (2003) model is based.

%%% � Ian Bruce (ibruce@ieee.org) March 2004 %%%
