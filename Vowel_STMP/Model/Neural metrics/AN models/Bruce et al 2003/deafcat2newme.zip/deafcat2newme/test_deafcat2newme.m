%

% model fiber parameters
BF   = 1e3; % BF in Hz;
cohc = 1;   % normal ohc function
cihc = 1;   % normal ihc function

% stimulus parameters
F0 = BF;     % stimulus frequency in Hz
Fs = 500e3;  % sampling rate = 500 kHz - THIS RATHER HIGH SAMPLING RATE IS ESSENTIAL FOR THE MODEL
T  = 0.1;    % stimulus duration in seconds
rt = 0.01;   % rise time in seconds
stimdb = 20; % stimulus intensity in dB SPL

% PSTH parameters
nrep = 100;            % number of stimulus repetitions (e.g., 100);
psthbinwidth = 0.1e-3; % binwidth in seconds;

t = 0:1/Fs:T-1/Fs; % time vector
pin = sqrt(2)*20e-6*10^(stimdb/20)*sin(2*pi*F0*t); % unramped stimulus

% Ramp stimulus on and off
mxpts = length(pin);
irpts = rt*Fs;
tind   = 0.0;
for lp = 1:irpts
    pin(lp) = pin(lp)*tind/irpts;
    tind = tind + 1.0;
end
tind = tind + mxpts-2*irpts;
for lp = (mxpts-irpts):mxpts
    pin(lp) = pin(lp)*((mxpts-tind) / irpts);
    tind = tind + 1.0;
end

[timeout,meout,bmout,tausp,vihc,synout,psth500k] ...
    = deafcat2newme(pin,BF,nrep,1e3/Fs,1e3*T,2e3*T,cohc,cihc);

psthbins = round(psthbinwidth*Fs);  % number of psth500k bins per psth bin
psthtime = timeout(1:psthbins:end); % time vector for psth
pr = sum(reshape(psth500k,psthbins,length(psth500k)/psthbins))/nrep; % pr of spike in each bin
psth = pr/psthbinwidth; % psth in units of spikes/s
