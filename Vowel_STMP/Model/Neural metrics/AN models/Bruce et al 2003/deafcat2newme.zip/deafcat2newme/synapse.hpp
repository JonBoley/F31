#ifdef _MSC_VER
#include "synapse_msc.hpp"
#else
#include "synapse_unix.hpp"
#endif