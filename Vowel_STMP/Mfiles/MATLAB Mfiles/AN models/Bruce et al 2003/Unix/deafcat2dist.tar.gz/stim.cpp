#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "stim.hpp"
//T_stim tm001;
void stimulus_noise(T_stim *ptm);
//this is defined in cmpa.hpp; also used here to detect if the simulus exceed the buffer
#define MAXBUFFERNO 32000   //Max size of the buffer, when used in memory mode

//----------------------------------------------------------------------------------
double gasdev(void)
{
  int iset;
  double v1,v2,r,fac,gset,gasdeviate;
  
  iset = 0;
  
  if (iset == 0) {
    //label1: 	v1 = 2. * drand48() - 1.;
	label1: 	v1 = 2. * rand() - 1.;
    //v2 = 2. * drand48() - 1.;
	v2 = 2. * rand() - 1.;
    r = v1 * v1 + v2 * v2;
    if(r > 1.) goto label1;
    fac = sqrt(-2.*log(r)/r);
    gset = v1 * fac;
    gasdeviate = v2 * fac;
    iset = 1;
  }
  else {
    gasdeviate = gset;
    iset = 0;
  }
  return gasdeviate;
};

// ----Get stimulus choice from command lined --------------------------------
int GetStimChoise(T_stim *ptm, int idxnow,int argc,char* argv[])
/* the argc, argv are same as main, idxnow shows where to start, 
   return value show where is the end */
{
  int stim;
  char *para;
  para = argv[++idxnow];
  if((*para) == 'h')
  {
    printf("Stimulus type (\n1:tone=1\n2:noise\n3:click\n4:huffman sequence\n");
    printf("5:resonance\n6:SAM\n7:SAM noise\n8:two tone\n9:tone+narrow band noise\n");
    return(idxnow);
  };

  stim = atoi(para);
  ptm->stim = stim;
  if(stim ==-1) {
    printf("\n-stim # ... -> generate desired stimulus(time in ms scale)");
    printf("\n (tone) = 1 freqt spl dur reptim");
    printf("\n (noise) = 2 spl dur reptim");
    printf("\n (click) = 3 spl reptim");
    printf("\n (huffman) = 4 ...");
    printf("\n (resonance) = 5 ...");
    printf("\n (SAM) = 6 ...");
    printf("\n (SAM noise) = 7 ...");
    printf("\n (two tone) = 8 F1 F2 spl1 spl2 dur reptim");
    printf("\n (tone+narrow noise) = 9 ...");
    printf("\n");
  };
  if(stim == 1) {			/* TONE  */		
    ptm->freqt = double(atof(argv[++idxnow])); //frequency tone
    ptm->spl = double(atof(argv[++idxnow]));   //printf("SPL:\n");
    ptm->dur = double(atof(argv[++idxnow]));   //printf("Tone Duration(ms):\n");
    ptm->reptim = double(atof(argv[++idxnow]));//printf("Repetition Time(ms):\n");
    ptm->dur=ptm->dur*1e-3;
    ptm->reptim=ptm->reptim*1e-3;
  }
  else if(stim == 2) {		/* NOISE */
    ptm->spl = double(atof(argv[++idxnow]));//printf("SPL(dB):\n");
    ptm->dur = double(atof(argv[++idxnow]));//printf("Noise Duration(ms):\n");
    ptm->reptim = double(atof(argv[++idxnow]));//printf("Repetition Time(ms):\n");
    ptm->dur=ptm->dur*1e-3;
    ptm->reptim=ptm->reptim*1e-3;
  }
  else if(stim == 3) {		/*  CLICK   */
    ptm->spl = atof(argv[++idxnow]);//printf("SPL (dB):\n");
    ptm->reptim = atof(argv[++idxnow]);//printf("Reptime(ms):\n");
    ptm->reptim=ptm->reptim*1e-3;
    ptm->dur = ptm->reptim;
  }
  else if(stim == 4) {		/*  HUFFMAN SEQUENCE   */
    ptm->ft = atof(argv[++idxnow]);//printf("Ft:\n");
    ptm->spl = atof(argv[++idxnow]);//printf("SPL (dB):\n");
    ptm->reptim = 150.*1e-3;
  }
  if(stim == 5) {		/* RESONANCE  */		
    ptm->freqt = atof(argv[++idxnow]);//printf("Resonance Freq(Hz):\n");
    ptm->z = atof(argv[++idxnow]);//printf("z:\n");
    ptm->spl = atof(argv[++idxnow]);//printf("SPL:\n");
    ptm->reptim = atof(argv[++idxnow]);//printf("Repetition Time(ms):\n");
    ptm->reptim=ptm->reptim*1e-3;
  }
  if(stim == 6) {	 	/* SAM  */
    ptm->freqt = atof(argv[++idxnow]);//printf("Tone Freq(Hz):\n");
    ptm->fm = atof(argv[++idxnow]);//printf("Mod Freq(Hz):\n");
    ptm->modind = atof(argv[++idxnow]);//printf("Mod index:\n");
    ptm->spl = atof(argv[++idxnow]);//printf("SPL (Fc):\n");
    ptm->dur = atof(argv[++idxnow]);//printf("Tone Duration(ms):\n");
    ptm->reptim = atof(argv[++idxnow]);//printf("Repetition Time(ms):\n");
    ptm->dur=ptm->dur*1e-3;
    ptm->reptim=ptm->reptim*1e-3;
  }
  if(stim == 7) {	 	/* SAM Noise */
    ptm->fm = atof(argv[++idxnow]);//printf("Mod Freq(Hz):\n");
    ptm->modind = atof(argv[++idxnow]);//printf("Mod index:\n");
    ptm->spl = atof(argv[++idxnow]);//printf("SPL (Fc):\n");
    ptm->dur = atof(argv[++idxnow]);//printf("Tone Duration(ms):\n");
    ptm->reptim = atof(argv[++idxnow]);//printf("Repetition Time(ms):\n");
    ptm->dur=ptm->dur*1e-3;
    ptm->reptim=ptm->reptim*1e-3;
  }
  if(stim == 8) {	       /* TWO-TONE  */		
    ptm->F1 = atof(argv[++idxnow]);//printf("F1(Hz):\n");	
    ptm->F2 = atof(argv[++idxnow]);//printf("F2(Hz):\n");
    ptm->spl1 = atof(argv[++idxnow]);//printf("SPL (F1):\n");
    ptm->spl2 = atof(argv[++idxnow]);//printf("SPL (F2):\n");
    ptm->dur = atof(argv[++idxnow]);//printf("Tone Duration(ms):\n");
    ptm->reptim = atof(argv[++idxnow]);//printf("Repetition Time(ms):\n");
    ptm->dur=ptm->dur*1e-3;
    ptm->reptim=ptm->reptim*1e-3;
  }
  if(stim == 9) {  		/* Tone & Narrowband-Noise  */
    ptm->freqt = atof(argv[++idxnow]);//printf("Tone Freq(Hz):\n");
    ptm->spl = atof(argv[++idxnow]);//printf("Tone SPL:\n");
    ptm->splnoi = atof(argv[++idxnow]);//printf("Noise SPL (spectral level):\n");
    ptm->dur = atof(argv[++idxnow]);//printf("Tone & Noise Duration(ms):\n");
    ptm->reptim = atof(argv[++idxnow]);//printf("Repetition Time(ms):\n");
    ptm->dur=ptm->dur*1e-3;
    ptm->reptim=ptm->reptim*1e-3;
  }
return(idxnow);
};

// ----------------------------------------------------------------------------
/* ****************************************************************************
   stimulus amplitudes are in "pascals" (not necessarily true anymore 10/5/91)
   Conversion: 10v-Peak = 7.07v-rms = 130dB gain = 90dB SPL re 20uPa = .632 Pa
   Peak amplitude: 10v-peak rarefaction equals 0.894 Pa   
   **************************************************************************** */
void stimulus_generate(T_stim *ptm)
{
#define SPLTOA(spl) (0.894 * pow( 10.0 , (spl - 90.0) / 20.0))
  double A;
  int i,irpts;

  int stim = ptm->stim;

  //ptm->nstim = (int)(ptm->reptim / ptm->tdres);
  //for( i = 0; i < ptm->nstim; i++) ptm->buf[i] = 0.;  /* zero out buffer */
  switch(stim)
    {
    case 11: /* get stimulus from file */
      stimulus_file(ptm);
      break;
    case 1: /* tone */ 
      stimulus_tone(ptm);
      break;
    case 8: /* two tone */
      stimulus_2tone(ptm);
      break;
    case 9: /* Narrow-Band of Noise */
      stimulus_noiseband(ptm);
      break;
    case 3: /* work on click (100 usec duration, when tdres=50 usec)  */
      A = SPLTOA(ptm->spl);
      irpts = (int)(100e-6/ptm->tdres);
      for(i=0;i<irpts;i++)
	{
	  ptm->buf[i] = A;
	};
      ptm->nstim = (int)(ptm->reptim / ptm->tdres);
      break;
    case 2: // Noise
      stimulus_noise(ptm);
      break;
   default:
      break;
    };
};

// ----------------------------------------------------------------------------
void stimulus_file(T_stim *ptm)
{
  FILE *fp;
  double tmp;
  int i = 0,j,total;
  //int i = 0,total;
  //double *buf,reptim,tdres,nstim,maxpoint;
  double *buf,tdres,maxpoint;

  maxpoint = MAXBUFFERNO-1;
  tdres = ptm->tdres;
  buf = ptm->buf;
  fp = fopen(ptm->wavefile,"r+");

  while((!feof(fp))&&(!ferror(fp)))
  {
    fscanf(fp,"%f",&tmp);
    buf[i] = tmp;
    printf("%f \n",tmp);
    i++;
    if(i>maxpoint) break;
  };
  total = (int)(0.020/tdres);
  for(j = i;j<i+total;j++)
    {
      buf[j] = 0.0;
      j++;
      if(j>maxpoint) break;
    };
  ptm->nstim = j;
  ptm->reptim = j*tdres;
  ptm->dur = j*tdres;
  fclose(fp);
};
// ----------------------------------------------------------------------------
/* caculate the rise/fall according different method  
   linear = 1;
   m_cos = 2;
*/
double getrise(int method,double totalpts,double nowpts)
{
  double value;
  switch(method)
    {
    default:
    case 1: value = nowpts/totalpts; break;
    case 2: value = 0.5-0.5*cos(nowpts/totalpts*TWOPI/2.0); break;
    };
return(value);
};

// ----------------------------------------------------------------------------
/* changes made on 1/5/00 : now the rise/fall using 5ms half cos */
void stimulus_tone(T_stim *ptm)
{
  double freqt,spl,rf,reptim,dur,tdres;
  double *buf;
  int nstim;

  double A,t;
  //int i,j,irpts,mxpts;
  int i,irpts,mxpts;
  double phase;
  int method = ptm->rfmethod; //using cos to caculate the rise fall
  reptim = ptm->reptim;
  tdres = ptm->tdres;
  freqt = ptm->freqt;
  spl = ptm->spl;
  rf = ptm->rf; //rise fall

  dur = ptm->dur;
  buf = ptm->buf;

  nstim = (int)(reptim / tdres);
  ptm->nstim = nstim;
  for( i = 0; i < nstim; i++) buf[i] = 0.;  /* zero out buffer */

  //phase = drand48()*TWOPI;
  phase = 0;
  //  rf = _rf; 3/12/99 3.9 * 1e-3; rise/fall
  /*A is a scaling value that adjusts each waveform so that they are in dB SPL*/
  A = .894 * pow( 10. , (spl - 90)/20.);
  mxpts = (int)(dur / tdres);
  irpts = (int)(rf / tdres);
  t = 0.;
  for(i = 0; i < irpts; i++)
    {
      t = t + 1.0;
      buf[i] = A * getrise(method,irpts,t) * sin(phase + TWOPI * freqt * tdres * t);
    }
  for(i = irpts; i < (mxpts-irpts); i++)
    {
      t = t + 1.0;
      buf[i] = A * sin(phase + TWOPI * freqt * tdres * t);
    }
  for(i = (mxpts-irpts); i < mxpts; i++)
    {
      t = t + 1.0;
      buf[i] = A * getrise(method,irpts,mxpts-t) * sin(phase + TWOPI * freqt * tdres * t);
    }

  return;
};

// ----------------------------------------------------------------------------
/* global variable used:   tdres, nstim* */
void stimulus_2tone2(T_stim *ptm)
{
  double F1,F2,F1spl,F2spl,rf,reptim,dur,*buf;
  double tdres;
  int nstim;

  double t,A1,A2;
  //int i,irpts,mxpts,idumr;
  int i,irpts,mxpts;
  double phase1,phase2;
  int method = ptm->rfmethod; //using linear/cos rise/fall
  F1 = ptm->F1; F1spl = ptm->spl1;
  F2 = ptm->F2; F2spl = ptm->spl2;
  rf = ptm->rf; dur = ptm->dur;
  buf = ptm->buf;
  //ptm->reptim = (int)(ptm->reptim*F1)/F1;
  reptim = ptm->reptim;
  tdres = ptm->tdres;

  nstim = (int)(reptim / tdres);
  ptm->nstim = nstim;
  //phase1 = TWOPI*drand48();
  //phase2 = TWOPI*drand48();
  phase1 = phase2 = 0.0;
  //phase2 = TWOPI*drand48();
  phase2 = TWOPI*rand();
  A1 = .894 * pow( 10. , (F1spl - 90)/20.);
  for( i = 0; i < nstim; i++) buf[i] = A1*sin(TWOPI*F1*tdres*i);
  
  rf = ptm->rf;  /*   rise/fall   */
  /*A is a scaling value that adjusts each waveform so that they are in dB SPL*/	
  A2 = .894 * pow( 10. , (F2spl - 90)/20.);  
  
  mxpts = (int)(dur / tdres);
  irpts = (int)(rf / tdres);
  t = 0.;
  for(i = 0; i < irpts; i++) {
    t = t + 1.0;
    buf[i] = buf[i] + getrise(method,irpts,t) * A2 * sin(TWOPI * F2 * tdres * t + phase2);
  }
  for(i = irpts; i < (mxpts-irpts); i++) {
    t = t + 1.0;
    buf[i] = buf[i] + A2 * sin(TWOPI * F2 * tdres * t + phase2);
  }
  for(i = (mxpts-irpts); i < mxpts; i++) {
    t = t + 1.0;
    buf[i] = buf[i] + getrise(method,irpts,mxpts-t) * A2 * sin(TWOPI * F2 * tdres * t + phase2);
  }
  return;
};

// ----------------------------------------------------------------------------
/* global variable used:   tdres, nstim* */
void stimulus_2tone(T_stim *ptm)
{
  double F1,F2,F1spl,F2spl,rf,reptim,dur,*buf;
  double tdres;
  int nstim;

  double t,A1,A2;
  //int i,irpts,mxpts,idumr;
  int i,irpts,mxpts;
  double phase1,phase2;
  int method = ptm->rfmethod; //using cos/linear rise/fall
  F1 = ptm->F1; F1spl = ptm->spl1;
  F2 = ptm->F2; F2spl = ptm->spl2;
  rf = ptm->rf; dur = ptm->dur;
  buf = ptm->buf;
  reptim = ptm->reptim;
  tdres = ptm->tdres;

  nstim = (int)(reptim / tdres);
  ptm->nstim = nstim;
  //phase1 = TWOPI*drand48();
  //phase2 = TWOPI*drand48();
  phase1 = phase2 = 0.0;
  for( i = 0; i < nstim; i++) buf[i] = 0.;  /* zero out buffer */
  
  rf = ptm->rf;  /*   rise/fall   */
  /*A is a scaling value that adjusts each waveform so that they are in dB SPL*/	
  A1 = .894 * pow( 10. , (F1spl - 90)/20.);
  A2 = .894 * pow( 10. , (F2spl - 90)/20.);  
  
  mxpts = (int)(dur / tdres);
  irpts = (int)(rf / tdres);
  t = 0.;
  for(i = 0; i < irpts; i++) {
    t = t + 1.0;
    buf[i] = getrise(method,irpts,t) * (A1 * sin(TWOPI * F1 * tdres * t + phase1) + 
					A2 * sin(TWOPI * F2 * tdres * t + phase2)) ;
  }
  for(i = irpts; i < (mxpts-irpts); i++) {
    t = t + 1.0;
    buf[i] = A1 * sin(TWOPI * F1 * tdres * t + phase1) + 
             A2 * sin(TWOPI * F2 * tdres * t + phase2);
  }
  for(i = (mxpts-irpts); i < mxpts; i++) {
    t = t + 1.0;
    buf[i] = getrise(method,irpts,mxpts-t) * (A1 * sin(TWOPI * F1 * tdres * t + phase1) + 
					      A2 * sin(TWOPI * F2 * tdres * t + phase2));
  }
  return;
};

// ----------------------------------------------------------------------------
void stimu_noiseband(double tdres,double freqt, double spl, double splnoi,
		     double rf, double reptim, double dur, double* buf);
void stimulus_noiseband(T_stim *ptm)
{ ptm->nstim = (int)(ptm->reptim/ptm->tdres);
  stimu_noiseband(ptm->tdres,ptm->freqt,ptm->spl,ptm->splnoi,
		  ptm->rf,ptm->reptim,ptm->dur,ptm->buf); 
};
void stimu_noiseband(double tdres,double freqt, double spl, double splnoi,
		     double rf, double reptim, double dur, double* buf)
{

  double An,At,band,f0,lofreq,hifreq,invn;
  double rdum;
  int i,n,ipts,fnumlo,fnumhi,fnum,numband;
  COMPLEX w[4096],wi[4096],data[4096]; 
  double mag[1024],phase[1024];
  /*static double phbuf[11] = 
    { 0.43, 1.39, 1.43, -2.77, 0.66, -1.36, -2.83, -0.56, -2.12, 2.66, -2.29 }; */
  static double phbuf[11] = 
    { 1.24, 0.88, 1.52, -2.14, -0.90, -0.49, 2.76, 1.63, 2.49, 2.24, -0.69 };
  //3/13/99
  //rf = 5. * 1e-3;
  //w = (struct complex*)calloc(sizeof(struct complex)

  band = 100.;
  n = 2048;
  f0 = 1./(n * tdres);
  lofreq = freqt - band/2.;
  hifreq = freqt + band/2;
  fnumlo = (int)(lofreq/f0);
  fnumhi = (int)(hifreq/f0);
  fnum = (int)(freqt/f0);
  numband = fnumhi - fnumlo + 1;
  
  fftinit(w,wi,n);
  
  for(i = 0;i<n/2;i++){
    mag[i] = .00001;
    phase[i] = 0.;
  }
  for(i = fnumlo; i <= fnumhi; i++) {
    mag[i] = 1.;
    phase[i] = phbuf[i - fnumlo];
  }

  /*  mag[51] = 1.;  */ 
  /* phase[51] = 0.; */   /* tone */
  
  /* CONVERT FROM MAG & ANGLE TO RECTANGULAR complex*/
  
  for(i = 0;i<n/2;i++){
    CMPLX(data[i],(mag[i] * cos(phase[i])), (mag[i] * sin(phase[i])));
  }
  
  fft(data,wi,n);
  invn = 1./n;

  An = .894 * pow( 10. , (splnoi - 90)/20.);
  At = .894 * pow( 10., (spl - 90)/20.);
  
  for(i = 0;i<n;i++){
    buf[i] = (double)( (data[i].x) * An * 1414. / n ) 
      + At * sin(TWOPI * freqt * tdres * (double)(i)) ;   /* scale by 1/n for inverse fft */
  }				/* Note: 1.414 * 1000. scales it up to Pa */

  ipts = (int)(rf / tdres);  /* # pts in rise and fall times */
  for(i = 0; i < ipts; i++) { 
    rdum = sin(TWOPI*i*tdres / (4. * rf ));
    buf[i] = buf[i] * rdum * rdum;
  }
  for( i = (int)(dur/tdres - ipts); i < (int)(dur/tdres); i++) {
    rdum = sin(TWOPI*i*tdres / (4. * rf ));
    buf[i] = buf[i] * rdum * rdum;
  };
  for (i = (int)(dur/tdres); i < (int)(reptim/tdres); i++) buf[i] = 0.;
return;
}

// ----------------------------------------------------------------------------
void stimulus_noise(T_stim *ptm)
{
  /* NOISE WAVEFORM  fill ibuf w/random #'s */
  int i;
  int irpts = (int)(ptm->rf / ptm->tdres);
  int mxpts = (int)(ptm->dur / ptm->tdres);
  int nstim = (int)(ptm->reptim / ptm->tdres);
  int method = 2; //rise fall = cos
  ptm->nstim = nstim;

  double *buf = ptm->buf;
  for( i = 0; i < mxpts; i++) {
    buf[i] = gasdev();
    /* check for #s more than 4sd from mean; if true, call gasdev again.
       ( not likely to happen more than once in a row.) */
    while( (buf[i] > 4.) | (buf[i] < -4.)) buf[i] = gasdev();
    buf[i] = buf[i] * 32767./4.;     /*c normalize to max possible value of 32000. */  
  }
  /*  SCALE AMPLITUDE  */
  double A = .894 * pow( 10., (ptm->spl-90)/20.);
  /* gate the noise with a trapezoid   */
  double t = 0.;
  for(i = 0; i < irpts; i++) {
    t = t + 1.0;
    buf[i] = A * getrise(method,irpts,t) * buf[i] / 32000.;
  }
  for(i = irpts; i < (mxpts-irpts); i++) {
    t = t + 1.0;
    buf[i] = A * buf[i] / 32000.;
  }
  for(i = (mxpts-irpts); i < mxpts; i++) {
    t = t + 1.0;
    buf[i] = getrise(method,irpts,(mxpts - t)) * A * buf[i] / 32000.;
  }
  for(i = mxpts; i < nstim; i++) {
    t = t + 1.0;
    buf[i] = 0.;
  }
  return;
};
	

