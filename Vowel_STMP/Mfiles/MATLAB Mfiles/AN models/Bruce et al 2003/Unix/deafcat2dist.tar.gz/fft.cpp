/* fast Fourier transform (FFT)   ---    without test routine  ----
(from "C Tools for Scientists and Engineers" by L.Baker)

CONTENTS:

log2
   integer log to base 2 of an integer power of two
bitr
   do bit reversal for FFT array addressing
fftinit
   initialize arrays for given size (n) fft
fft
   perform FFT

DEPENDENCIES:
complex.h header file required

*/
#include <stdlib.h>
#include <math.h>
#include "complex.hpp"
#define twopi 6.283185307

int iterp; /* global to return count used */

#define max(a,b) (((a) > (b))? (a): (b))
#define abs(x) ((x)? (x):-(x))

int bitr(int k,int logn)
{
  int ans,j,i;
  ans = 0;
  j = k;
  for(i = 0;i<logn;i++)
    {
      ans=(ans<<1)+(j&1);
      j = j>>1;
    }
  return(ans);
};

int log2(int n)
{
  int i;
  i = -1; /* will return -1 if n<=0 */
  while(1)
    {
      if(n == 0) break;
      n = n>>1;
      i++;
    }
  return(i);
};
/** 
Construct the complex array for fft
@return void
@parameter n : No. of points
@parameter w[] : output of the array
@parameter wi[] : output of the array
*/
void fftinit(COMPLEX w[],COMPLEX wi[],int n)
{
  int i;
  double realpt,imagpt;
  double factr,angle;
  factr=twopi/n;
  
  for(i=0;i<n;i++)
    {
      angle=i*factr;
      realpt=cos(angle);imagpt=sin(angle);
      CMPLX(w[i],realpt,imagpt);
      CMPLX(wi[i],realpt,(-imagpt));
    }
  return;
}
/**
   do fft
   @return      value stored in x[]
   @param n   : No. of points
   @param w[] : base of the fft
   @param x[] : input/output
 */
void fft(COMPLEX x[],COMPLEX w[],int n)
{
//  int n1,logn,i,j,k,l,l1,logl,exponent,p;
	int n1,logn,i,j,k,l,logl,p;
//  COMPLEX s,t,a,b;
    COMPLEX s,t;
  logn = log2(n);
  n1 = n>>1;
  j = logn-1;
  /* transform */
  k = 0;
  for(logl=0;logl<logn;logl++)
    {
      do{
	for(i=0;i<n1;i++)
	  {
	    p=bitr((k>>j),logn);
	    l=k+n1;
	    CONJG(s,w[p]);
	    CMULT(t,s,x[l]);
	    CSUB(x[l],x[k],t);
	    CADD(x[k],t,x[k]);
	    k++;
	  };/* dofor i*/
	k+=n1;
      } while ( k < n );
      k=0;
      j--;
      n1=n1>>1;
    }
  
  /* reorder */
  for(i=1;i<n;i++)
    {
      k=bitr(i,logn);
      if(i>k)
	{
	  /* exchange i,k elements */
	  CLET(s,x[i]);
	  CLET(x[i],x[k]);
	  CLET(x[k],s);
	}
    };
  
  return;
};
























