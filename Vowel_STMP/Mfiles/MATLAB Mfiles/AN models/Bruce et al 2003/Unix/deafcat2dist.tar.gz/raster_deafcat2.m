% model fiber parameters
BF   = 1e3; % BF = 1 kHz;
cohc = 1;   % normal ohc function
cihc = 1;   % normal ihc function

% stimulus parameters
F0 = BF;     % stimulus frequency = BF
Fs = 500e3;  % sampling rate = 500 kHz - THIS RATHER HIGH SAMPLING RATE IS ESSENTIAL FOR THE MODEL
T  = 0.1;    % stimulus duration = 100 ms
rt = 0.01;   % rise time = 10 ms
stimdb = 20; % stimulus intensity in dB SPL

% PSTH parameters
nrep = 100;            % number of stimulus repetitions = 100;
%psthbinwidth = 0.1e-3; % binwidth = 0.1 ms;
psthbinwidth = 1e-3; % binwidth = 1 ms;

t = 0:1/Fs:T-1/Fs; % time vector
pin = sqrt(2)*20e-6*10^(stimdb/20)*sin(2*pi*F0*t); % unramped stimulus

% Ramp stimulus on and off
mxpts = length(pin);
irpts = rt*Fs;
tind   = 0.0;
for lp = 1:irpts
    pin(lp) = pin(lp)*tind/irpts;
    tind = tind + 1.0;
end
tind = tind + mxpts-2*irpts;
for lp = (mxpts-irpts):mxpts
    pin(lp) = pin(lp)*((mxpts-tind) / irpts);
    tind = tind + 1.0;
end

figure

raster = zeros(nrep,round(2*T/psthbinwidth));
psthbins = round(psthbinwidth*Fs);  % number of psth500k bins per psth bin

for lp=1:nrep
    
    [timeout,meout,bmout,tausp,vihc,synout,psth500k] ...
        = deafcat2(pin,BF,1,1e3/Fs,1e3*T,2e3*T,cohc,cihc);

    psth = sum(reshape(psth500k,psthbins,length(psth500k)/psthbins)); % psth
    
    raster(lp,:) = psth;
    
    plot(timeout(find(psth>0)),lp*ones(1,length(find(psth>0))),'bo','markerfacecolor','b','markersize',2)
    hold on
    
end

pr = sum(raster)/nrep;
psth = pr/psthbinwidth;

psthtime = timeout(1:psthbins:end); % time vector for psth
