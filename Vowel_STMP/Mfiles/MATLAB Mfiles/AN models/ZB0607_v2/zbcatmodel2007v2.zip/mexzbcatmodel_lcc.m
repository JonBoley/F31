mex -v LINKFLAGSPOST#"$LINKFLAGSPOST libgslML.lib libgslcblasML.lib" zbcatmodel.c complex.c
