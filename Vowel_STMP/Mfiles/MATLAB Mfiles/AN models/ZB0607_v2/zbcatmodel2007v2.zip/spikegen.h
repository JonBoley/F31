#ifdef _WIN32
#include "spikegen_win32.h"
#else
#include "spikegen_unix.h"
#endif
