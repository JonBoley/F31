mex -v zbcatmodel.c complex.c
